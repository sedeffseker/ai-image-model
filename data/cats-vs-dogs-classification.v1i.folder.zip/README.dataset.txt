# cats-vs-dogs-classification > 2025-12-28 1:48am
https://universe.roboflow.com/imageaiproject/cats-vs-dogs-classification

Provided by a Roboflow user
License: CC BY 4.0

